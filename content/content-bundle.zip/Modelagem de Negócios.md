
## Design Thinking, SWOT, Canvas e Análise de Cenários 


1. Design Thinking:
    
    - Livro: "Design Thinking: Inovação em Negócios" de Tim Brown.
    - Curso Online Gratuito: "Introduction to Design Thinking" ([https://www.ideou.com/pages/design-thinking](https://www.ideou.com/pages/design-thinking)) oferecido pela IDEO U.
    - Artigo: "Design Thinking for Business Innovation" ([https://hbr.org/2008/06/design-thinking](https://hbr.org/2008/06/design-thinking)) da Harvard Business Review.
2. Análise SWOT (Strengths, Weaknesses, Opportunities, Threats):
    
    - Artigo: "A Practical Guide to SWOT Analysis" ([https://www.smartsheet.com/ultimate-guide-swot-analysis](https://www.smartsheet.com/ultimate-guide-swot-analysis)) da Smartsheet.
    - Modelo de Planilha: "SWOT Analysis Template" ([https://www.vertex42.com/ExcelTemplates/swot-analysis.html](https://www.vertex42.com/ExcelTemplates/swot-analysis.html)) da Vertex42.
    - Vídeo: "How to Perform a SWOT Analysis" ([https://youtu.be/BCEmkwEOWpM](https://youtu.be/BCEmkwEOWpM)) do canal de YouTube "Project Management Videos".
3. Canvas de Modelo de Negócios:
    
    - Site: Business Model Canvas ([https://strategyzer.com/canvas/business-model-canvas](https://strategyzer.com/canvas/business-model-canvas)) - Recurso oficial do Business Model Canvas, com informações detalhadas e exemplos.
    - Livro: "Business Model Generation" de Alexander Osterwalder e Yves Pigneur - Este livro explora o uso do Business Model Canvas e apresenta casos de estudo.
    - Vídeo: "How to Create a Business Model Canvas" ([https://youtu.be/ipT7xeCz8lQ](https://youtu.be/ipT7xeCz8lQ)) do canal de YouTube "Steve Blank".
4. Análise de Cenários:
    
    - Artigo: "Scenario Analysis: A Tool for Task Managers" ([https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4010846/](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4010846/)) da revista "Emerging Infectious Diseases".
    - Livro: "Scenario Planning: A Field Guide to the Future" de Woody Wade - Este livro aborda técnicas e métodos de análise de cenários.
    - Vídeo: "Scenario Planning" ([https://youtu.be/8Db_y47aJPA](https://youtu.be/8Db_y47aJPA)) da Global Economic Symposium.
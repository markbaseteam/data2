---
quickshare-date: 2023-05-25 21:46:35
quickshare-url: "https://noteshare.space/note/cli3uekd33017201pjz8q12170#jP/LJptMsm4ySL/hukJH0m11L23knMeYke6p9q1+E+A"
---

## Fluxograma de estudos:

```mermaid
graph TD
    A[Fundamentos de Negócios] --> B[Estatística e Análise de Dados]
    B --> C[Excel/Sheets]
    C --> D[SQL]
    D --> E[Python e PowerBI/Tableau]
    E --> F[Análise de Processos]
    F --> G[Métodos Avançados]

    style A fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    style B fill:#bbdefb,stroke:#1565c0,stroke-width:2px
    style C fill:#fff9c4,stroke:#fbc02d,stroke-width:2px
    style D fill:#e1bee7,stroke:#6a1b9a,stroke-width:2px
    style E fill:#f3f573,stroke:#73ccf5,stroke-width:2px
    style F fill:#b3e5fc,stroke:#0277bd,stroke-width:2px
    style G fill:#b3475f,stroke:#241216,stroke-width:2px
    

```

1. [[Fundamentos de Negócios]]
   - Noções básicas de economia e finanças
   - Compreensão do ambiente de negócios
   - Conceitos de gestão empresarial

2. [[Estatística e Análise de Dados]]
   - Estatística descritiva e inferencial
   - Probabilidade e distribuições
   - Técnicas de amostragem
   - Análise exploratória de dados
   - Regressão linear e análise de correlação
   - Teste de hipóteses

3. [[Ferramentas e Tecnologias]]
   - Planilhas (como Microsoft Excel ou Google Sheets)
   - Bancos de dados relacionais (como SQL)
   - Linguagem de programação (como Python ou R)
   - Visualização de dados (como Tableau ou Power BI)
   - Ferramentas de análise de dados (como SAS ou SPSS)

4. [[Modelagem de Negócios]]
   - Análise SWOT
   - Matriz BCG
   - Análise de cadeia de valor
   - Modelos de negócios (como Canvas)

5. [[Análise de Processos de Negócios]]
   - Mapeamento de processos
   - Identificação de gargalos e oportunidades de melhoria
   - Análise de fluxo de valor
   - Notação BPMN (Business Process Model and Notation)

6. [[Métodos de Análise Avançados]]
   - Análise de regressão múltipla
   - Análise de séries temporais
   - Análise de clusterização
   - Análise de dados não estruturados (como texto ou redes sociais)

7. [[Habilidades de Comunicação e Apresentação]]
   - Capacidade de comunicar resultados de análises de forma clara e concisa
   - Elaboração de relatórios e apresentações eficazes
   - Habilidades de visualização de dados

8. [[Conhecimento do Domínio de Negócios]]
   - Familiaridade com o setor ou indústria específica em que você pretende trabalhar como analista de negócios**

---

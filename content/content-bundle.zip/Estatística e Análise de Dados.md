### Análise de Dados

1. Vídeos:
   - "Statistics 101" (https://youtu.be/xxpc-HPKN28) - Este curso em vídeo oferece uma introdução abrangente à estatística, abordando conceitos fundamentais e técnicas estatísticas.
   - "Data Analysis and Statistical Inference" (https://www.coursera.org/learn/data-analysis-statistical-inference) - Este curso online gratuito do Coursera ensina estatística e inferência estatística usando exemplos práticos e exercícios interativos.

2. Textos:
   - "OpenIntro Statistics" (https://www.openintro.org/stat/textbook.php) - Este livro-texto de estatística aberta oferece uma introdução clara e acessível aos princípios básicos de estatística, com exemplos e exercícios.
   - "Introduction to Statistical Learning" (http://faculty.marshall.usc.edu/gareth-james/ISL/) - Este livro, disponível gratuitamente online, aborda conceitos estatísticos e técnicas de aprendizado de máquina de uma maneira mais aplicada.

3. Livros:
   - "The Elements of Statistical Learning" de Trevor Hastie, Robert Tibshirani e Jerome Friedman - Este livro é uma referência clássica para técnicas avançadas de aprendizado de máquina e análise de dados.
   - "Think Stats" de Allen B. Downey - Este livro aborda estatística usando a linguagem de programação Python e enfoca a análise exploratória de dados.

Esses recursos oferecem uma base sólida para compreender e aplicar os princípios da estatística e da análise de dados. Além disso, plataformas de aprendizado online, como Udemy, edX e DataCamp, também oferecem cursos interativos e práticos sobre estatística e análise de dados, muitos dos quais possuem opções gratuitas ou de baixo custo.

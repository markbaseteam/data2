1. Gerenciamento de Projetos:
    
    - Vídeo: "Introduction to Project Management" ([https://youtu.be/ZrZ2PO3w5k8](https://youtu.be/ZrZ2PO3w5k8)) - Este vídeo oferece uma introdução abrangente ao gerenciamento de projetos, abordando conceitos básicos, metodologias e melhores práticas.
    - Artigo: "A Guide to the Project Management Body of Knowledge (PMBOK® Guide)" - O PMBOK® Guide é uma referência amplamente utilizada no gerenciamento de projetos, disponível em formato de livro, mas também existem resumos e materiais online gratuitos baseados nele.
    - Livro: "Project Management for Dummies" de Stanley E. Portny - Este livro aborda os princípios fundamentais do gerenciamento de projetos de forma acessível e prática.
2. Gerenciamento de Processos de Negócio (BPM):
    
    - Vídeo: "Introduction to Business Process Management" ([https://youtu.be/bwbL6c3aD2k](https://youtu.be/bwbL6c3aD2k)) - Este vídeo fornece uma introdução ao BPM, explicando conceitos, metodologias e benefícios.
    - Artigo: "The Complete Guide to Business Process Management" ([https://www.tallyfy.com/business-process-management/](https://www.tallyfy.com/business-process-management/)) da Tallyfy - Este guia completo explora os aspectos essenciais do BPM e oferece insights sobre como implementar e melhorar processos de negócios.
    - Livro: "Business Process Management: Concepts, Languages, Architectures" de Mathias Weske - Este livro abrange os fundamentos do BPM, incluindo conceitos, metodologias e exemplos práticos.
3. Gerenciamento de Mudanças:
    
    - Vídeo: "Introduction to Change Management" ([https://youtu.be/9iLiRHHO5Wo](https://youtu.be/9iLiRHHO5Wo)) - Este vídeo apresenta uma visão geral do gerenciamento de mudanças, explicando o que é, por que é importante e como implementá-lo.
    - Artigo: "The Change Management Process: 8 Steps to Success" ([https://www.smartsheet.com/8-steps-effective-change-management-process](https://www.smartsheet.com/8-steps-effective-change-management-process)) da Smartsheet - Este artigo fornece um guia passo a passo para o processo de gerenciamento de mudanças, destacando as etapas cruciais e melhores práticas.
    - Livro: "Leading Change" de John P. Kotter - Este livro clássico explora os princípios e estratégias para liderar mudanças eficazes nas organizações.